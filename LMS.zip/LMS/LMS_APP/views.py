from django.shortcuts import redirect, render
from .models import *
from .forms import BookForm ,AuthorForm ,PublisherForm,CategoryForm,LibrarianForm,MemberForm,Memphones
from django.db.models import Sum
# Create your views here.
def index (request):
    if request.method == 'POST' :
      if 'title' in request.POST:
        add_book = BookForm(request.POST, request.FILES)
        if add_book.is_valid ():
            add_book.save()
      elif 'name' in request.POST:
        add_author = AuthorForm(request.POST, request.FILES)
        if add_author.is_valid () :
            add_author.save()
      elif 'Pname' in request.POST:
        add_pub = PublisherForm(request.POST, request.FILES)
        if add_pub.is_valid ():
            add_pub.save()
      elif 'category_name' in request.POST:
        add_cat = CategoryForm(request.POST, request.FILES)
        if add_cat.is_valid ():
            add_cat.save()
      else:
        add_lib = LibrarianForm(request.POST, request.FILES)
        if add_lib.is_valid ():
            add_lib.save()
         
    context = {
        'books' : Books.objects.all(),
        'author' : Author.objects.all(),
        'publisher' : Publisher.objects.all(),
        'category' : Category.objects.all(),
        'librarian' : Librarian.objects.all(),
        'form' : BookForm(),
        'formm' : AuthorForm(),
        'formpub':PublisherForm(),
        'formcat':CategoryForm(),
        'formlib':LibrarianForm(),
        'allbooks':Books.objects.aggregate(total_quantity=Sum('quantity'))['total_quantity'] or 0,
        'booksold':Books.objects.aggregate(total_quantity=Sum('quantity'))['total_quantity']or 0,
        'bookrent':Books.objects.count() or 0,
        'tot' :Books.objects.aggregate(total_quantity=Sum('price'))['total_quantity'] or 0,
        'aval': Books.objects.exclude(quantity=0).aggregate(total_quantity=Sum('quantity'))['total_quantity'] or 0
         }
    return render(request,'pages/index.html',context)
def books (request):
    context = {
        'books' : Books.objects.all(),
        'author' : Author.objects.all(),
        'publisher' : Publisher.objects.all(),
        'category' : Category.objects.all(),
        'librarian' : Librarian.objects.all(),
    }
    return render(request,'pages/books.html',context)
def delete (request,id):
    book_delete=Books.objects.get(id=id)
    if request.method == 'POST' :
       book_delete.delete()
       return redirect('/')
    return render(request,'pages/delete.html')
def update (request , id):
    book_id =Books.objects.get(id=id)
    if request.method == 'POST' :
       book_save = BookForm(request.POST, request.FILES , instance=book_id)
       if book_save.is_valid ():
            book_save.save()
            return redirect('/')
    else :
       book_save = BookForm(instance=book_id)
    context = {
       'formeditbook' : book_save
    }
    return render(request,'pages/update.html',context)

def members (request):
    if request.method == 'POST' :
      if 'phone_number' in request.POST:
        add_phonemem = MemberForm(request.POST, request.FILES)
        if add_phonemem.is_valid ():
            add_phonemem.save()
      else:
        add_mem = MemberForm(request.POST, request.FILES)
        if add_mem.is_valid ():
            add_mem.save()
    context = {
        'books' : Books.objects.all(),
        'author' : Author.objects.all(),
        'publisher' : Publisher.objects.all(),
        'category' : Category.objects.all(),
        'librarian' : Librarian.objects.all(),
        'member' : Member.objects.all(),
        'formmem' :MemberForm(),
        'formphone' :Memphones()
    }
    return render(request,'pages/members.html',context)

# def base (request):
#     context = {
#         'books' : Books.objects.all(),
#         'author' : Author.objects.all(),
#         'publisher' : Publisher.objects.all(),
#         'category' : Category.objects.all(),
#         'librarian' : Librarian.objects.all(),
#     }
#     return render(request,'base.html',context)
