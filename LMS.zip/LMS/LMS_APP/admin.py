from django.contrib import admin
from .models import Author,Publisher,Category,Librarian,Books,Member,MemberphoneNumber,Buying,Borrowing
# Register your models here.
admin.site.register(Author)
admin.site.register(Publisher)
admin.site.register(Category)
admin.site.register(Librarian)
admin.site.register(Books)
admin.site.register(Member)
admin.site.register(MemberphoneNumber)
admin.site.register(Buying)
admin.site.register(Borrowing)