from django.db import models
from django.db.models import F
from datetime import timedelta, date
from django.utils import timezone

class Author(models.Model):
    name = models.CharField(max_length=250)
    author_photo = models.ImageField(upload_to='photos',null=True, blank=True)
    biography = models.TextField()
    
    def __str__(self):
      return self.name
    
class Publisher(models.Model):
    Pname = models.CharField(max_length=250,unique=True)
    contactinfo = models.TextField(null=True, blank=True)
    
    def __str__(self):
        return self.Pname
    
class Category(models.Model):
    category_name = models.CharField(max_length=250,unique=True)
    
    def __str__(self):
        return self.category_name

class Librarian(models.Model):
    firstname = models.CharField(max_length=100)
    middlename = models.CharField(max_length=100, blank=True, null=True)
    lastname = models.CharField(max_length=100)
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(max_length=50, unique=True)
    librarian_photo = models.ImageField(upload_to='photos',null=True, blank=True)
    role = models.CharField(choices=[('manager','Manager'), ('cashier','Cashier')])
    
    def __str__(self):
        full_lib_name = f"{self.firstname} {self.middlename or ''} {self.lastname}".strip()
        return " ".join(full_lib_name.split())
    
class Books(models.Model):
    title = models.CharField(max_length=250)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    book_photo = models.ImageField(upload_to='photos',null=True, blank=True)
    pages = models.IntegerField(blank=True, null=True)
    year = models.PositiveIntegerField(blank=True, null=True)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    rental_price_day = models.DecimalField(max_digits=5, decimal_places=2)
    shelf_location = models.CharField(max_length=250, editable=False)
    quantity = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=20, default="Available")
    manager = models.ForeignKey(
        Librarian,
        on_delete=models.PROTECT,
        limit_choices_to={'role': 'manager'},
        related_name='managed_books'
    )
    
    def save(self, *args, **kwargs):
        self.shelf_location = f"{self.category.category_name} Section"
        if self.quantity <= 0:
            self.status = "Sold Out"
        else:
            self.status = "Available"
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.title

class Member(models.Model):
    first_name = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100, unique=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    member_photo = models.ImageField(null=True, blank=True)
    membership_date = models.DateTimeField(default=timezone.now)
    email = models.EmailField(max_length=50, unique=True)

    @property
    def full_name(self):
        full_name = f"{self.first_name} {self.middle_name or ''} {self.last_name}".strip()
        return " ".join(full_name.split())
    
    def __str__(self):
        return self.full_name

class MemberphoneNumber(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE, related_name='phone_numbers')
    phone_number = models.CharField(max_length=20)

    def __str__(self):
        return self.phone_number

class Buying(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    cashier = models.ForeignKey(Librarian, on_delete=models.CASCADE, limit_choices_to={'role': 'cashier'}, related_name='buying_books')
    buying_book = models.ForeignKey(Books, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    PaymentMethod = models.CharField(choices=[('cash','Cash'), ('visa','Visa')])

    def save(self, *args, **kwargs):
        if self.quantity <= 0:
            raise ValueError("الكمية يجب أن تكون أكبر من 0")

        book = Books.objects.select_for_update().get(pk=self.buying_book.pk)

        if book.quantity < self.quantity:
            raise ValueError("لا توجد كمية كافية من هذا الكتاب.")

        book.quantity -= self.quantity
        book.status = "Available" if book.quantity > 0 else "Sold Out"
        book.save()

        self.total_price = self.quantity * book.price
        self.buying_book = book

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Buying {self.quantity} of {self.buying_book.title} by {self.member.username} {self.PaymentMethod}"

class Borrowing(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    borrowing_book = models.ForeignKey(Books, on_delete=models.CASCADE)
    librarian = models.ForeignKey(Librarian, on_delete=models.CASCADE, related_name='borrowing_books')
    borrow_date = models.DateTimeField(default=timezone.now)
    duration_days = models.PositiveIntegerField()
    return_date = models.DateTimeField(blank=True, null=True)
    total_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    PaymentMethod = models.CharField(choices=[('cash','Cash'), ('visa','Visa')])
    def save(self, *args, **kwargs):
        book = Books.objects.select_for_update().get(pk=self.borrowing_book.pk)

        if book.quantity <= 0:
            raise ValueError("This book is currently unavailable.")

        book.quantity -= 1
        book.status = "Available" if book.quantity > 0 else "Sold Out"
        book.save()

        self.return_date = self.borrow_date + timezone.timedelta(days=self.duration_days)
        self.total_price = self.duration_days * book.rental_price_day

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.member} borrowed {self.borrowing_book.title} {self.PaymentMethod}"