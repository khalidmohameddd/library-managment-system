from django import forms
from .models import Books, Category ,Author,Publisher,Librarian,Member,MemberphoneNumber
class BookForm (forms.ModelForm) :
    class Meta:
        model = Books
        fields = [
            'title' ,
            'author' ,
            'publisher', 
            'category' ,
            'book_photo',
            'pages' ,
            'year' ,
            'price' ,
            'rental_price_day', 
            'quantity' ,
            'status' ,
            'manager' ,
        ]
class AuthorForm (forms.ModelForm) :
    class Meta:
        model = Author
        fields = '__all__'

class PublisherForm (forms.ModelForm) :
    class Meta:
        model = Publisher
        fields = '__all__'

class CategoryForm (forms.ModelForm) :
    class Meta:
        model = Category
        fields = ['category_name']
        widgets = {
            'category_name' : forms.TextInput(attrs={'class':'form-control'})
        }

class LibrarianForm (forms.ModelForm) :
    class Meta:
        model = Librarian
        fields = [
            'firstname' ,
            'middlename' ,
            'lastname', 
            'username' ,
            'email',
            'librarian_photo' ,
            'role' ,
        ]
    
class MemberForm (forms.ModelForm) :
    class Meta:
        model = Member
        fields = '__all__'

class Memphones (forms.ModelForm) :
    class Meta:
        model = MemberphoneNumber
        fields ='__all__'